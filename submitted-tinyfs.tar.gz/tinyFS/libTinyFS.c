#include <ctype.h>
#include <string.h>
#include <stdio.h>

#include "bitset.h"
#include "libTinyFS.h"
#include "slice.h"

#ifdef DEBUG_FLAG
	#define dbg(...) fprintf(stderr, __VA_ARGS__)
#else
	#define dbg(...)
#endif

#define FILENAMESIZE 8
#define DEFAULT_TABLE_SIZE 8

#define MINDISKSIZE (BLOCKSIZE * 3)
#define MAXDISKSIZE (BLOCKSIZE << 8)

#define BLOCKHDRSIZE 4
#define BLOCKDATSIZE (BLOCKSIZE - BLOCKHDRSIZE)
#define INODEHDRSIZE (BLOCKHDRSIZE + FILENAMESIZE + 1 + sizeof(int) + 1)
#define INODEDATSIZE (BLOCKSIZE - INODEHDRSIZE)

#define BLOCK_SUPER 1
#define BLOCK_INODE 2
#define BLOCK_EXTENT 3
#define BLOCK_FREE 4

#define F_ISDIR 1
#define F_WRITE 2
#define F_READ 4
#define F_RDWR (F_READ | F_WRITE)

#define ADDR_SUPER 0
#define ADDR_ROOT 1
#define ADDR_START 2

#define IS_BAD_BLOCK(block) ((block)[0] > BLOCK_FREE || (block)[1] != 0x44 || (block)[3] != 0)

typedef struct {
	int bNum, modified;
	unsigned char data[BLOCKSIZE];
} Block;

typedef struct {
	unsigned int inode, dir;
	char name[FILENAMESIZE];
	int ptr, size;
	unsigned char flags;
	Block buf;
} File;

int mnt = -1;

slice_t fileTable;
int nextFD = -1;

Block super;
int nextBlock = -1;
int diskBlocks = -1;

File root;

static inline int blockNum(int ptr) {
	return ((ptr - INODEDATSIZE) / BLOCKDATSIZE) + (ptr >= INODEDATSIZE);
}

static inline int ptrIndex(int ptr, int* off) {
	if (ptr < INODEDATSIZE) {
		if (off != NULL) *off = INODEHDRSIZE;
		return ptr + INODEHDRSIZE;
	}
	if (off != NULL) *off = BLOCKHDRSIZE;
	ptr = (ptr - INODEDATSIZE) % BLOCKDATSIZE;
	return ptr + BLOCKHDRSIZE;
}

int _writeBlock(Block* block) {
	if (block->modified == 0) {
		return 0;
	}
	dbg("writing block %d to disk\n", block->bNum);
	int err = writeBlock(mnt, block->bNum, block->data);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	block->modified = 0;
	return 0;
}

int _readBlock(int bNum, Block* block) {
	if (bNum == block->bNum) {
		return 0;
	}
	int err = _writeBlock(block);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	err = readBlock(mnt, bNum, block->data);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	block->bNum = bNum;
	return 0;
}

fileDescriptor nextFreeFD(void) {
	dbg("nextFreeFD()\n");
	int fd = nextFD;
	if (fd >= 0) {
		nextFD = -1;
		return fd;
	}
	for (int i = 0; i < fileTable.len; i++) {
		if (((File*) fileTable.ptr)[i].inode <= 0) {
			return i;
		}
	}
	return -1;
}

int nextFreeBlock(void) {
	dbg("nextFreeBlock()\n");
	int bNum = nextBlock;
	if (bNum > 0) {
		nextBlock = -1;
		return bNum;
	}
	bNum = bitset_ctz(super.data+6, diskBlocks);
	if (bNum < diskBlocks) {
		return bNum + 2;
	}
	return -1;
}

int tfs_mkfs(char* filename, int nBytes) {
	dbg("tfs_mkfs(%s, %d)\n", filename, nBytes);
	if (nBytes < MINDISKSIZE) {
		return ERR_INVALID;
	} else if (nBytes > MAXDISKSIZE) {
		return ERR_NOSPACE;
	}
	int nBlocks = nBytes / BLOCKSIZE;
	int disk = openDisk(filename, nBytes);
	if (IS_TFS_ERROR(disk)) {
		return disk;
	}
	/* Initialize free blocks */
	unsigned char block[BLOCKSIZE] = {BLOCK_FREE, 0x44};
	int err;
	for (int i = ADDR_START; i < nBlocks; i++) {
		err = writeBlock(disk, i, block);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
	}
	/* Initialize root dir */
	block[0] = BLOCK_INODE;
	block[BLOCKHDRSIZE+FILENAMESIZE+1] = INODEDATSIZE;
	block[INODEHDRSIZE-1] = F_RDWR | F_ISDIR;
	err = writeBlock(disk, ADDR_ROOT, block);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	block[BLOCKHDRSIZE+FILENAMESIZE+1] = 0;
	block[INODEHDRSIZE-1] = 0;
	/* Initialize superblock */
	block[0] = BLOCK_SUPER;
	block[2] = ADDR_ROOT;
	nBlocks -= 2;
	block[4] = nBlocks;
	block[5] = nBlocks >> 8;
	int n = (nBlocks + 7) >> 3; // num. bytes needed to represent each block as a bit
	n += 6;
	for (int i = 6; i < n; i++) {
		block[i] = 0xff;
	}
	block[n-1] >>= (8 - (nBlocks & 7)) & 7;
	err = writeBlock(disk, ADDR_SUPER, block);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	return closeDisk(disk);
}

int readValidBlock(int disk, int bNum, unsigned char* block) {
	int err = readBlock(disk, bNum, block);
	if (IS_TFS_ERROR(err)) {
		return err;
	} else if (IS_BAD_BLOCK(block)) {
		return ERR_NOTBLOCK;
	}
	return 0;
}

int tfs_mount(char* diskname) {
	dbg("tfs_mount(%s)\n", diskname);
	if (mnt >= 0) {
		return ERR_BUSY;
	}
	int disk = openDisk(diskname, 0);
	if (IS_TFS_ERROR(disk)) {
		return disk;
	}
	int err = readValidBlock(disk, ADDR_SUPER, super.data);
	if (IS_TFS_ERROR(err)) {
		return err;
	} else if (super.data[0] != BLOCK_SUPER || super.data[2] != ADDR_ROOT) {
		return ERR_NOTBLOCK;
	}
	super.bNum = ADDR_SUPER;
	diskBlocks = ((unsigned int) super.data[4]) |
				 ((unsigned int) super.data[5]) << 8;
	err = readValidBlock(disk, ADDR_ROOT, root.buf.data);
	if (IS_TFS_ERROR(err)) {
		return err;
	} else if (root.buf.data[0] != BLOCK_INODE) {
		return ERR_NOTBLOCK;
	}
	root.buf.bNum = ADDR_ROOT;
	root.inode = ADDR_ROOT;
	unsigned char block[BLOCKSIZE];
	for (int i = ADDR_ROOT+1; i < super.data[4]; i++) {
		err = readValidBlock(disk, i, block);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
	}
	mnt = disk;
	fileTable = slice_new(DEFAULT_TABLE_SIZE, sizeof(File));
	return 0;
}

int tfs_unmount(void) {
	dbg("tfs_unmount(%d)\n", mnt);
	if (mnt < 0) {
		dbg("bad mnt\n");
		return ERR_NODEVICE;
	}
	int disk = mnt;
	mnt = -1;
	nextFD = -1;
	nextBlock = -1;
	diskBlocks = -1;
	slice_free(fileTable);
	int err = writeBlock(disk, ADDR_SUPER, super.data);
	if (IS_TFS_ERROR(err)) {
		dbg("error writing super\n");
		return err;
	}
	return closeDisk(disk);
}

int checkName(char* name, int dir) {
	int n = 0, size = strlen(name);
	if (size == 0) {
		return ERR_INVALID;
 	}
	for (int i = 0; i < size; i++) {
		if (name[i] == '/') {
			if (n > FILENAMESIZE) {
				return ERR_NAMETOOLONG;
			}
			n = 0;
		} else if (!isalnum(name[i])) {
			return ERR_INVALID;
		} else {
			++n;
		}
	}
	if (n > FILENAMESIZE) {
		return ERR_NAMETOOLONG;
	}
	return 0;
}

char* parsePath(char* path) {
	dbg("parsePath(%s)\n", path);
	int n = strlen(path);
	while (n > 0 && path[n-1] == '/') {
		path[--n] = '\0';
	}
	dbg("path: %s\n", path);
	if (n == 0) {
		dbg("n == 0\n");
		return NULL;
	}
	char* name = strrchr(path, '/');
	dbg("name: %s\n", name);
	if (name) {
		*name = '\0';
		return name + 1;
	}
	return path;
}


int openFile(int bNum, File* file) {
	dbg("openFile(%d)\n", bNum);
	int err = _readBlock(bNum, &file->buf);
	if (IS_TFS_ERROR(err)) {
		dbg("error reading block\n");
		return err;
	} else if (file->buf.data[0] != BLOCK_INODE) {
		dbg("block is not inode (%d)\n", file->buf.data[0]);
		return ERR_IO;
	}
	file->inode = bNum;
	file->ptr = 0;
	int idx = BLOCKHDRSIZE;
	memcpy(file->name, file->buf.data+idx, FILENAMESIZE);
	idx += FILENAMESIZE;
	file->dir = file->buf.data[idx++];
	file->size = ((unsigned int) file->buf.data[idx])       |
				 ((unsigned int) file->buf.data[idx+1]) << 8  |
				 ((unsigned int) file->buf.data[idx+2]) << 16 |
				 ((unsigned int) file->buf.data[idx+3]) << 24;
	idx += sizeof(unsigned int);
	file->flags = file->buf.data[idx] & 0b111;
	return 0;
}

int nextFile(File* dir, char** name, int* firstFree) {
	dbg("nextFile()\n");
	static const int step = FILENAMESIZE + 1;
	int idx, off;
	idx = ptrIndex(dir->ptr, &off);
	int nBytes = BLOCKSIZE - idx;
	if (nBytes < step) {
		int bNum = dir->buf.data[2];
		if (bNum <= 0) {
			return ERR_EOF;
		}
		int err = _readBlock(bNum, &dir->buf);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
		dir->ptr += nBytes;
		idx = BLOCKHDRSIZE;
	}
	int addr = dir->buf.data[idx+FILENAMESIZE];
	if (addr == 0 && firstFree != NULL && *firstFree < 0) {
		*firstFree = dir->ptr;
	}
	*name = (char*) (dir->buf.data+idx);
	if (addr == 0) {
		dbg("empty\n");
	} else {
		dbg("%.*s: %d\n", FILENAMESIZE, *name, addr);
	}
	dir->ptr += step;
	return addr;
}

int seekFile(File* file, int offset) {
	dbg("seekFile(%d)\n", offset);
	if (offset < 0) {
		return ERR_INVALID;
	} else if (offset == file->ptr) {
		return 0;
	} else if (offset >= file->size) {
		file->ptr = offset;
		return 0;
	}
	int ptrBlock = blockNum(file->ptr);
	int offBlock = blockNum(offset);
	int bNum, nBlocks;
	if (offBlock < ptrBlock) {
		bNum = file->inode;
		nBlocks = offBlock + 1;
	} else {
		bNum = file->buf.data[2];
		nBlocks = offBlock - ptrBlock;
	}
	int err;
	while (bNum > 0 && nBlocks > 0) {
		err = _readBlock(bNum, &file->buf);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
		bNum = file->buf.data[2];
		--nBlocks;
	}
	file->ptr = offset;
	return 0;
}

int extendFile(File* file, int nBytes) {
	dbg("extendFile(%d)\n", nBytes);
	int trailing;
	if (file->size <= INODEDATSIZE) {
		trailing = INODEDATSIZE - file->size;
	} else {
		trailing = (file->size - INODEDATSIZE) % BLOCKDATSIZE;
		if (trailing) trailing = BLOCKDATSIZE - trailing;
	}
	dbg("%d trailing bytes\n", trailing);
	int nBlocks = 0;
	if (nBytes > trailing) {
		dbg("nBytes > trailing\n");
		nBlocks = ((nBytes-trailing) + (BLOCKDATSIZE-1)) / BLOCKDATSIZE;
	} else {
		trailing = nBytes;
	}
	if (trailing < 1 && nBlocks < 1) {
		return 0;
	}
	Block start;
	memcpy(&start, &(file->buf), sizeof(Block));
	int startPtr = file->ptr;
	int err, bNum = file->buf.data[2];
	while (bNum > 0) {
		dbg("_readBlock(%d)\n", bNum);
		err = _readBlock(bNum, &file->buf);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
		bNum = file->buf.data[2];
	}
	int first = -1;
	if (trailing > 0) {
		dbg("%d trailing bytes remain\n", trailing);
		memset(file->buf.data+(BLOCKSIZE-trailing), 0, trailing);
		file->buf.modified = 1;
		if (nBlocks == 0) {
			err = _writeBlock(&file->buf);
			if (IS_TFS_ERROR(err)) {
				return err;
			}
		}
		first = file->buf.bNum;
	}
	while (nBlocks > 0) {
		bNum = nextFreeBlock();
		if (bNum <= 0) {
			return ERR_NOSPACE;
		}
		if (first == -1) {
			first = bNum;
		}
		file->buf.data[2] = bNum;
		err = writeBlock(mnt, file->buf.bNum, file->buf.data);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
		file->buf.bNum = bNum;
		memset(file->buf.data+2, 0, BLOCKSIZE-2);
		file->buf.data[0] = BLOCK_EXTENT;
		err = writeBlock(mnt, bNum, file->buf.data);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
		bitset_clear(super.data+6, bNum-2);
		super.modified = 1;
		--nBlocks;
	}
	err = _writeBlock(&super);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	if (file->buf.bNum != file->inode) {
		err = seekFile(file, 0);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
	}
	file->size += nBytes;
	static const int idx = BLOCKHDRSIZE + FILENAMESIZE + 1;
	file->buf.data[idx] =   ((unsigned int) file->size);
	file->buf.data[idx+1] = ((unsigned int) file->size) >> 8;
	file->buf.data[idx+2] = ((unsigned int) file->size) >> 16;
	file->buf.data[idx+3] = ((unsigned int) file->size) >> 24;
	err = writeBlock(mnt, file->inode, file->buf.data);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	if (file->ptr != startPtr) {
		memcpy(&(file->buf), &start, sizeof(Block));
		file->ptr = startPtr;
	}
	return first;
}

int findInDir(char* name, File* dir) {
	dbg("findInDir(%s)\n", name);
	int err = seekFile(dir, 0);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	int bNum;
	char* namep;
	while ((bNum = nextFile(dir, &namep, NULL)) >= 0) {
		if (bNum != 0 && strncmp(name, namep, FILENAMESIZE) == 0) {
			dbg("Found!\n");
			break;
		}
	}
	return (bNum == ERR_EOF) ? ERR_NOENTRY : bNum;
}

int findOrPutInDir(char* name, File* dir, unsigned char flags, int size) {
	dbg("findOrPutInDir(%s, %.8s/)\n", name, dir->name);
	int err = seekFile(dir, 0);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	int bNum, firstFree = -1;
	char* namep;
	while ((bNum = nextFile(dir, &namep, &firstFree)) >= 0) {
		dbg("name: %.*s, namep: %.*s\n", FILENAMESIZE, name, FILENAMESIZE, namep);
		if (bNum != 0 && strncmp(name, namep, FILENAMESIZE) == 0) {
			dbg("Found!\n");
			return bNum;
		}
	}
	if (firstFree == -1) {
		if (IS_TFS_ERROR(bNum) && bNum != ERR_EOF) {
			return bNum;
		}
		dbg("need to grow dir\n");
		firstFree = dir->size;
		bNum = extendFile(dir, BLOCKDATSIZE);
		if (IS_TFS_ERROR(bNum)) {
			return bNum;
		}
	}
	dbg("Not found!\n");
	err = seekFile(dir, firstFree);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	bNum = nextFreeBlock();
	if (bNum <= 0) {
		return ERR_NOSPACE;
	}
	dbg("next free block: %d\n", bNum);
	int idx = ptrIndex(firstFree, NULL);
	dbg("idx: %d\n", idx);
	memset(dir->buf.data+idx, 0, FILENAMESIZE);
	strncpy((char*) (dir->buf.data+idx), name, FILENAMESIZE);
	dbg("name: %.*s, buf: %.*s\n", FILENAMESIZE, name, FILENAMESIZE, (char*) (dir->buf.data+idx));
	dir->buf.data[idx+FILENAMESIZE] = bNum;
	err = writeBlock(mnt, dir->buf.bNum, dir->buf.data);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	dbg("wrote block %d\n", dir->buf.bNum);
	char block[BLOCKSIZE] = {BLOCK_INODE, 0x44};
	idx = BLOCKHDRSIZE;
	strncpy(block+idx, name, FILENAMESIZE);
	idx += FILENAMESIZE;
	block[idx++] = dir->inode;
	if (size > 0) {
		block[idx]   = ((unsigned int) size);
		block[idx+1] = ((unsigned int) size) >> 8;
		block[idx+2] = ((unsigned int) size) >> 16;
		block[idx+3] = ((unsigned int) size) >> 24;
	}
	idx += sizeof(unsigned int);
	block[idx] = flags;
	err = writeBlock(mnt, bNum, block);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	dbg("wrote block %d\n", bNum);
	bitset_clear(super.data+6, bNum-2);
	super.modified = 1;
	err = _writeBlock(&super);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	dbg("wrote block %d\n", ADDR_SUPER);
	return bNum;
}

int openDir(char* path, File* dir) {
	dbg("openDir(%s)\n", path);
	int err = seekFile(&root, 0);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	File* curr = &root;
	char* name = strtok(path, "/");
	while (name != NULL) {
		int bNum = findInDir(name, curr);
		if (bNum <= 0) {
			return ERR_NOENTRY;
		}
		err = openFile(bNum, dir);
		if (IS_TFS_ERROR(err)) {
			return err;
		} else if ((dir->flags & F_ISDIR) == 0) {
			return ERR_NOTDIR;
		}
		curr = dir;
		name = strtok(NULL, "/");
	}
	return 0;
}

int _tfs_openFile(char* name, File* file, int create) {
//	name += strspn(name, "/");
//	int err = checkName(name);
//	if (IS_TFS_ERROR(err)) {
//		return err;
//	}
	int err;
	char* fname = parsePath(name);
	if (fname == NULL) {
		return ERR_INVALID;
	}
	dbg("name parsed\n");
	File* dir = &root;
	if (fname != name) {
		dbg("opening directory %s\n", name);
		err = openDir(name, file);
		if (IS_TFS_ERROR(err)) {
			dbg("error opening directory\n");
			return err;
		}
		dir = file;
	}
	int bNum;
	if (create) {
		bNum = findOrPutInDir(fname, dir, F_RDWR, 0);
	} else {
		bNum = findInDir(fname, dir);
	}
	if (IS_TFS_ERROR(bNum)) {
		dbg("error finding file\n");
		return bNum;
	}
	dbg("opening file %s\n", fname);
	err = openFile(bNum, file);
	if (IS_TFS_ERROR(err)) {
		dbg("error opening file\n");
		return err;
	}
	return 0;
}

fileDescriptor tfs_openFile(char* name) {
	dbg("tfs_openFile(%s)\n", name);
	File file = {0};
	name += strspn(name, "/");
	int err = checkName(name, 0);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	err = _tfs_openFile(name, &file, 1);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	fileDescriptor fd = nextFreeFD();
	if (fd < 0) {
		fd = fileTable.len;
		fileTable = slice_append(fileTable, &file);
	} else {
		memcpy(((File*) fileTable.ptr)+fd, &file, sizeof(File));
	}
	dbg("file opened (%d bytes, dir: %d)\n", file.size, file.dir);
	return fd;
}

int fileIsFree(void* value) {
	return ((File*) value)->inode <= 0;
}

int tfs_closeFile(fileDescriptor fd) {
	dbg("tfs_closeFile(%d)\n", fd);
	if (fd < 0 || fd >= fileTable.len) {
		return ERR_BADF;
	}
	File* fp = ((File*) fileTable.ptr) + fd;
	if (fp->inode <= 0) {
		return ERR_BADF;
	}
	int err = _writeBlock(&fp->buf);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	fp->inode = 0;
	fp->buf.bNum = 0;
	memset(fp->buf.data, 0, BLOCKSIZE);
	fileTable = slice_trim(fileTable, fileIsFree);
	return 0;
}

/* Free all blocks of fp from bNum to the EOF */
int freeBlocks(File* fp, int bNum) {
	dbg("freeBlocks(%d)\n", bNum);
	int err;
	while (bNum > 0) {
		err = _readBlock(bNum, &fp->buf);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
		bNum = fp->buf.data[2];
		fp->buf.data[0] = BLOCK_FREE;
		fp->buf.data[2] = 0;
		err = writeBlock(mnt, fp->buf.bNum, fp->buf.data);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
		dbg("freed block %d\n", fp->buf.bNum);
		if (nextBlock <= 0) {
			nextBlock = fp->buf.bNum;
		}
		bitset_set(super.data+6, fp->buf.bNum-2);
		super.modified = 1;
	}
	return _writeBlock(&super);
}


int tfs_writeFile(fileDescriptor fd, char* buffer, int size) {
	dbg("tfs_writeFile(%d, %d)\n", fd, size);
	if (fd < 0 || fd >= fileTable.len) {
		return ERR_BADF;
	}
	File* fp = ((File*) fileTable.ptr) + fd;
	int bNum = fp->inode;
	if (bNum <= 0) {
		return ERR_BADF;
	} else if ((fp->flags & F_WRITE) == 0) {
		dbg("no write access\n");
		return ERR_ACCESS;
	} else if ((fp->flags & F_ISDIR) != 0) {
		return ERR_ISDIR;
	}
	fp->size = size;
	int n, err;
	while (size > 0 && bNum > 0) {
		err = _readBlock(bNum, &fp->buf);
		if (IS_TFS_ERROR(err)) {
			dbg("error reading block #%d\n", bNum);
			return err;
		}
		if (bNum == fp->inode) {
			fp->buf.data[0] = BLOCK_INODE;
			int idx = BLOCKHDRSIZE + FILENAMESIZE + 1;
			fp->buf.data[idx]   = ((unsigned int) size);
			fp->buf.data[idx+1] = ((unsigned int) size) >> 8;
			fp->buf.data[idx+2] = ((unsigned int) size) >> 16;
			fp->buf.data[idx+3] = ((unsigned int) size) >> 24;
			n = (size < INODEDATSIZE) ? size : INODEDATSIZE;
			memcpy(fp->buf.data+INODEHDRSIZE, buffer, n);
		} else {
			fp->buf.data[0] = BLOCK_EXTENT;
			n = (size < BLOCKDATSIZE) ? size : BLOCKDATSIZE;
			memcpy(fp->buf.data+BLOCKHDRSIZE, buffer, n);
		}
		bNum = fp->buf.data[2];
		if (size <= n) {
			dbg("last block\n");
			fp->buf.data[2] = 0;
		} else if (bNum <= 0) {
			dbg("need new block\n");
			if ((bNum = nextFreeBlock()) <= 0) {
				return ERR_NOSPACE;
			}
			fp->buf.data[2] = bNum;
			bitset_clear(super.data+6, bNum-2);
			super.modified = 1;
		}
		err = writeBlock(mnt, fp->buf.bNum, fp->buf.data);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
		buffer += n;
		size -= n;
	}
	if (size > 0) {
		dbg("didn't write whole file\n");
		return ERR_IO;
	}
	err = freeBlocks(fp, bNum);
	if (IS_TFS_ERROR(err)) {
		dbg("error freeing blocks\n");
		return err;
	}
	fp->ptr = 0;
	return 0;
}

unsigned char emptyBlock[BLOCKSIZE] = {0};

int _tfs_deleteFile(File* fp) {
	int bNum = fp->inode;
	if (bNum <= 0) {
		return ERR_BADF;
	} else if ((fp->flags & F_WRITE) == 0) {
		return ERR_ACCESS;
	}
	int err = freeBlocks(fp, fp->inode);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	File dir = {0};
	err = openFile(fp->dir, &dir);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	char* namep;
	while ((bNum = nextFile(&dir, &namep, NULL)) >= 0) {
		if (bNum == fp->inode) {
			dbg("Found %.8s! clearing address\n", namep);
			memset(namep, 0, FILENAMESIZE+1);
			break;
		}
	}
	if (IS_TFS_ERROR(bNum)) {
		return bNum;
	}
	bNum = dir.buf.bNum;
	int keepLast = 1;
	if (dir.buf.data[2] <= 0 && bNum != dir.inode && bNum != ADDR_ROOT) {
		// last block of dir
		keepLast = memcmp(dir.buf.data+BLOCKHDRSIZE, emptyBlock, BLOCKDATSIZE);
	}
	dbg("dir bNum: %d\n", bNum);
	dbg("keepLast: %d\n", keepLast);
	if (keepLast) {
		err = writeBlock(mnt, bNum, dir.buf.data);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
		if (bNum == root.buf.bNum) {
			memcpy(root.buf.data, dir.buf.data, BLOCKSIZE);
		}
		return 0;
	}
	err = readBlock(mnt, dir.inode, dir.buf.data);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	dir.size -= BLOCKDATSIZE;
	int idx = BLOCKHDRSIZE + FILENAMESIZE + 1;
	dir.buf.data[idx++] = ((unsigned int) dir.size);
	dir.buf.data[idx++] = ((unsigned int) dir.size) >> 8;
	dir.buf.data[idx++] = ((unsigned int) dir.size) >> 16;
	dir.buf.data[idx++] = ((unsigned int) dir.size) >> 24;
	dir.buf.modified = 1;
	while (dir.buf.data[2] != bNum) {
		err = _readBlock(dir.buf.data[2], &dir.buf);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
	}
	dir.buf.data[2] = 0;
	err = writeBlock(mnt, dir.buf.bNum, dir.buf.data);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	return freeBlocks(&dir, bNum);
}

int tfs_deleteFile(fileDescriptor fd) {
	dbg("tfs_deleteFile(%d)\n", fd);
	if (fd < 0 || fd >= fileTable.len) {
		return ERR_BADF;
	}
	File* fp = ((File*) fileTable.ptr) + fd;
	if ((fp->flags & F_ISDIR) != 0) {
		return ERR_ISDIR;
	}
	int err = _tfs_deleteFile(fp);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	return tfs_closeFile(fd);
}

int tfs_readByte(fileDescriptor fd, char* buffer) {
	dbg("tfs_readByte(%d)\n", fd);
	if (fd < 0 || fd >= fileTable.len) {
		return ERR_BADF;
	}
	File* fp = ((File*) fileTable.ptr) + fd;
	if (fp->inode <= 0) {
		return ERR_BADF;
	} else if ((fp->flags & F_ISDIR) != 0) {
		return ERR_ISDIR;
	} else if (fp->ptr >= fp->size) {
		dbg("EOF\n");
		return ERR_EOF;
	}
	int err, idx, off;
	idx = ptrIndex(fp->ptr, &off);
	if (fp->ptr == 0 && fp->buf.bNum != fp->inode) {
		err = _readBlock(fp->inode, &fp->buf);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
	}
	*buffer = fp->buf.data[idx];
	if (idx >= BLOCKSIZE - 1) {
		int bNum = fp->buf.data[2];
		if (bNum <= 0) {
			return ERR_EOF;
		}
		err = _readBlock(bNum, &fp->buf);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
	}
	++fp->ptr;
	return 0;
}

int tfs_seek(fileDescriptor fd, int offset) {
	dbg("tfs_seek(%d, %d)\n", fd, offset);
	if (fd < 0 || fd >= fileTable.len) {
		return ERR_BADF;
	}
	File* fp = ((File*) fileTable.ptr) + fd;
	if (fp->inode <= 0) {
		return ERR_BADF;
	} else if ((fp->flags & F_ISDIR) != 0) {
		return ERR_ISDIR;
	}
	return seekFile(fp, offset);
}

void setFlags(unsigned char* block, unsigned char flags) {
	block[INODEHDRSIZE-1] |= flags;
}

void clearFlags(unsigned char* block, unsigned char flags) {
	block[INODEHDRSIZE-1] &= ~flags;
}

int makeFlags(char* name, unsigned char flags, void (*fn)(unsigned char*, unsigned char)) {
	name += strspn(name, "/");
	int err = checkName(name, 1);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	char* fname = parsePath(name);
	File file = {0};
	File* dir = &root;
	if (fname != name) {
		dbg("opening directory %s\n", name);
		err = openDir(name, &file);
		if (IS_TFS_ERROR(err)) {
			dbg("error opening directory\n");
			return err;
		}
		dir = &file;
	}
	int bNum = findInDir(fname, dir);
	if (IS_TFS_ERROR(bNum)) {
		dbg("error finding file\n");
		return bNum;
	}
	for (int i = 0; i < fileTable.len; i++) {
		File* fp = ((File*) fileTable.ptr) + i;
		if (fp->inode == bNum) {
			return ERR_BUSY;
		}
	}
	err = readBlock(mnt, bNum, file.buf.data);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	fn(file.buf.data, flags);
	return writeBlock(mnt, bNum, file.buf.data);
}

int tfs_makeRO(char* name) {
	return makeFlags(name, F_WRITE, clearFlags);
}

int tfs_makeRW(char* name) {
	return makeFlags(name, F_RDWR, setFlags);
}

int tfs_writeByte(fileDescriptor fd, unsigned int data) {
	dbg("tfs_writeByte(%d, %d)\n", fd, data);
	if (fd < 0 || fd >= fileTable.len) {
		return ERR_BADF;
	}
	File* fp = ((File*) fileTable.ptr) + fd;
	if (fp->inode <= 0) {
		return ERR_BADF;
	} else if ((fp->flags & F_WRITE) == 0) {
		dbg("no write access\n");
		return ERR_ACCESS;
	} else if ((fp->flags & F_ISDIR) != 0) {
		return ERR_ISDIR;
	}
	int err, bNum = fp->buf.bNum;
	if (fp->ptr >= fp->size) {
		bNum = extendFile(fp, (fp->ptr+1)-fp->size);
		if (IS_TFS_ERROR(bNum)) {
			return bNum;
		}
	}
	if (bNum != fp->buf.bNum) {
		err = _readBlock(bNum, &fp->buf);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
	}
	int idx;
	idx = ptrIndex(fp->ptr, NULL);
	fp->buf.data[idx] = data;
	fp->buf.modified = 1;
	if (idx >= BLOCKSIZE - 1) {
		int bNum = fp->buf.data[2];
		if (bNum <= 0) {
			return ERR_FAULT;
		}
		err = _readBlock(bNum, &fp->buf);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
	}
	++fp->ptr;
	return 0;
}

int tfs_createDir(char* dirName) {
	dbg("tfs_createDir(%s)\n", dirName);
	dirName += strspn(dirName, "/");
	int err = checkName(dirName, 1);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
//	char* fname = parsePath(dirName);
//	if (fname == NULL) {
//		return ERR_INVALID;
//	} else if (strlen(fname) > FILENAMESIZE) {
//		return ERR_NAMETOOLONG;
//	}
	File dir = {0};
	File* curr = &root;
	int bNum;
	char* name = strtok(dirName, "/");
	while (name != NULL) {
		bNum = findOrPutInDir(name, curr, F_RDWR | F_ISDIR, INODEDATSIZE);
		if (IS_TFS_ERROR(bNum)) {
			return bNum;
		}
		err = openFile(bNum, &dir);
		if (IS_TFS_ERROR(err)) {
			return err;
		} else if ((dir.flags & F_ISDIR) == 0) {
			return ERR_NOTDIR;
		}
		curr = &dir;
		name = strtok(NULL, "/");
	}
	return 0;
}

int tfs_removeDir(char* dirName) {
	File dir = {0};
	dirName += strspn(dirName, "/");
	int err = checkName(dirName, 1);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	err = _tfs_openFile(dirName, &dir, 0);
	if (IS_TFS_ERROR(err)) {
		return err;
	} else if ((dir.flags & F_ISDIR) == 0) {
		return ERR_NOTDIR;
	}
	dbg("removing dir %s with parent %d\n", dirName, dir.dir);
	for (int i = 0; i < fileTable.len; i++) {
		File* fp = ((File*) fileTable.ptr) + i;
		if (fp->inode == dir.inode) {
			return ERR_BUSY;
		}
	}
	int bNum;
	char* name;
	while ((bNum = nextFile(&dir, &name, NULL)) >= 0) {
		if (bNum != 0) {
			return ERR_NOTEMPTY;
		}
	}
	if (IS_TFS_ERROR(bNum) && bNum != ERR_EOF) {
		return bNum;
	}
	dbg("Delete %.8s\n", dir.name);
	return _tfs_deleteFile(&dir);
}

int _tfs_removeAll(File* dir) {
	File file = {0};
	int err, bNum;
	char* name;
	File* fp;
	for (int i = 0; i < fileTable.len; i++) {
		fp = ((File*) fileTable.ptr) + i;
		if (fp->inode > 0 && (fp->dir == dir->inode || fp->inode == dir->inode)) {
			return ERR_BUSY;
		}
	}
	while ((bNum = nextFile(dir, &name, NULL)) >= 0) {
		if (bNum == 0) {
			continue;
		}
		err = openFile(bNum, &file);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
		if ((file.flags & F_ISDIR) == 0) {
			err = _tfs_deleteFile(&file);
		} else {
			err = _tfs_removeAll(&file);
		}
		if (IS_TFS_ERROR(err)) {
			return err;
		}
	}
	if (IS_TFS_ERROR(bNum) && bNum != ERR_EOF) {
		return bNum;
	} else if (dir->inode == ADDR_ROOT) {
		return 0;
	}
	return _tfs_deleteFile(dir);
}

int tfs_removeAll(char* dirName) {
	int err, m, n = strlen(dirName);
	if (n == 0) {
		return ERR_INVALID;
	} else if ((m = strspn(dirName, "/")) == n) {
		err = seekFile(&root, 0);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
		return _tfs_removeAll(&root);
	}
	dirName += m;
	err = checkName(dirName, 1);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	File dir = {0};
	err = _tfs_openFile(dirName, &dir, 0);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	return _tfs_removeAll(&dir);
}

int tfs_rename(fileDescriptor fd, char* newName) {
	dbg("tfs_rename(%d, %s)", fd, newName);
	if (fd < 0 || fd >= fileTable.len) {
		return ERR_BADF;
	}
	File* fp = ((File*) fileTable.ptr) + fd;
	if (fp->inode <= 0) {
		return ERR_BADF;
	} else if ((fp->flags & F_WRITE) == 0) {
		dbg("no write access\n");
		return ERR_ACCESS;
	}
	int size = strlen(newName);
	if (size > FILENAMESIZE) {
		return ERR_NAMETOOLONG;
	}
	for (int i = 0; i < size; i++) {
		if (!isalnum(newName[i])) {
			return ERR_INVALID;
		}
	}
	int err;
	File fbuf = {0};
	char* pch;
	if (fp->buf.bNum == fp->inode) {
		pch = (char*) fp->buf.data;
	} else {
		pch = (char*) fbuf.buf.data;
		err = readBlock(mnt, fp->inode, pch);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
	}
	strncpy(pch+BLOCKHDRSIZE, newName, FILENAMESIZE);
	err = writeBlock(mnt, fp->inode, pch);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	err = openFile(fp->dir, &fbuf);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	while ((err = nextFile(&fbuf, &pch, NULL)) >= 0) {
		if (err != 0 && strncmp(fp->name, pch, FILENAMESIZE) == 0) {
			break;
		}
	}
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	strncpy(pch, newName, FILENAMESIZE);
	err = writeBlock(mnt, fbuf.buf.bNum, fbuf.buf.data);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	strncpy(fp->name, newName, FILENAMESIZE);
	return 0;
}

int _tfs_readdir(File* dir, int level, int* nDirs, int* nFiles) {
	int err, bNum;
	char* name;
	File file = {0};
	while ((bNum = nextFile(dir, &name, NULL)) >= 0) {
		if (bNum == 0) {
			continue;
		}
		err = openFile(bNum, &file);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
		for (int i = 0; i < level; i++) {
			printf("|   ");
		}
		printf("+-- %.8s", name);
		if ((file.flags & F_ISDIR) == 0) {
			printf("\n");
			++(*nFiles);
			continue;
		}
		printf("/\n");
		++(*nDirs);
		err = _tfs_readdir(&file, level+1, nDirs, nFiles);
		if (IS_TFS_ERROR(err)) {
			return err;
		}
	}
	return (bNum != ERR_EOF) ? bNum : 0;
}

int tfs_readdir(void) {
	int err = seekFile(&root, 0);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	int nDirs = 0, nFiles = 0;
	puts("/ (root)");
	err = _tfs_readdir(&root, 0, &nDirs, &nFiles);
	if (IS_TFS_ERROR(err)) {
		return err;
	}
	printf(
		"\n%d %s, %d %s\n",
		nDirs,
		(nDirs == 1) ? "directory" : "directories",
		nFiles,
		(nFiles == 1) ? "file" : "files"
	);
	return 0;
}

