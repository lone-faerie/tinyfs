#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tinyFS.h"
#include "libTinyFS.h"

fileDescriptor demoFD;
fileDescriptor* fds = NULL;
unsigned char nFiles = 0;

int testMount(char* diskName, int diskSize) {
	printf("\n===== Mounting %s =====\n", diskName);
	int err;
	if ((err = tfs_mount(diskName)) < 0) {
		if ((err = tfs_mkfs(diskName, diskSize)) < 0) {
			printf("Could not make fs on '%s' (%d)\n", diskName, err);
			return -1;
		}
		if ((err = tfs_mount(diskName)) < 0) {
			printf("Failed to mount '%s' (%d)\n", diskName, err);
			return -1;
		}
	}
	printf("Success!\n");
	return 0;
}

int testFirstRun(void) {
	printf("\n===== Checking First Run =====\n");
	demoFD = tfs_openFile("demo");
	if (demoFD < 0) {
		printf("Error opening 'demo' (%d)\n", demoFD);
		return -1;
	}
	char c;
	int firstRun = 0;
	int err = tfs_readByte(demoFD, &c);
	if (err == ERR_EOF) {
		firstRun = 1;
	} else if (err < 0) {
		printf("Error reading demoFD (%d)\n", err);
		return -1;
	} else {
		nFiles = (unsigned char) c;
	}
	printf("This is%s the first run.\n", firstRun ? "" : " not");
	return firstRun;
}

int testCreateFiles(void) {
	printf("\n===== Creating Files =====\n");
	printf("Enter how many files to create: ");
	int numFiles;
	scanf("%d", &numFiles);
	nFiles = numFiles;
	fds = malloc(nFiles * sizeof(fileDescriptor));
	char name[9] = {0};
	int retVal;
	for (int i = 0; i < nFiles; i++) {
		sprintf(name, "file%d", i);
		if ((retVal = tfs_openFile(name)) < 0) {
			printf("Error creating %s (%d)\n", name, retVal);
		} else {
			printf("%s created\n", name);
		}
		fds[i] = retVal;
	}
	return nFiles;
}

int testCreateDirs(void) {
	printf("\n===== Creating Directories =====\n");
	int nDirs;
	printf("Enter how many directories to create: ");
	scanf("%d", &nDirs);
	char name[9] = {0};
	int retVal;
	for (int i = 0; i < nDirs; i++) {
		sprintf(name, "dir%d", i);
		if ((retVal = tfs_createDir(name)) < 0) {
			printf("Error creating %s (%d)\n", name, retVal);
		} else {
			printf("%s created\n", name);
		}
	}
	return nDirs;
}

int testCreatePaths(void) {
	printf("\n===== Absolute Paths =====\n");
	int depth, numFiles;
	printf("Enter max depth of directories to create: ");
	scanf("%d", &depth);
	++depth;
	printf("Enter number of files to create: ");
	scanf("%d", &numFiles);
	char* name = calloc(depth, 9);
	char* name2 = calloc(depth, 9);
	char buf[10];
	int err, i, j, n;
	for (i = 0; i < numFiles; i++) {
		n = (rand() % (depth-1)) + 1;
		for (j = 0; j < n; j++) {
			sprintf(buf, "dir%d/", rand()%(depth-1));
			strcat(name, buf);
		}
		memcpy(name2, name, depth*9);
		if ((err = tfs_createDir(name)) < 0) {
			printf("Error creating %s\n", name);
		}
		sprintf(buf, "file%d", rand()%1000);
		strcat(name2, buf);
		memcpy(name, name2, depth*9);
		if ((err = tfs_openFile(name2)) < 0) {
			printf("Error creating %s\n", name2);
		} else {
			printf("%s created\n", name);
		}
		memset(name, 0, depth*9);
	}
	free(name);
	free(name2);
	char bar[] = "/foo///bar";
	if ((err = tfs_createDir(bar)) < 0) {
		printf("Error creating /foo/bar (%d)\n", err);
	}
	int fd;
	char baz[] = "/foo/baz";
	if ((fd = tfs_openFile(baz)) < 0) {
		printf("Error creating /foo/baz (%d)\n", fd);
	} else {
		tfs_closeFile(fd);
	}
	char foobar[] = "/foo/bar/foobar";
	if ((fd = tfs_openFile(foobar)) < 0) {
		printf("Error creating /foo/bar/foobar (%d)\n", fd);
	} else {
		tfs_closeFile(fd);
	}
	return numFiles;
}

int testWriteFiles(void) {
	printf("\n===== Write Files =====\n");
	int err, nBytes;
	printf("Enter how many bytes to write to each file: ");
	scanf("%d", &nBytes);
	char* buffer = malloc(nBytes);
	for (int i = 0; i < nBytes; i++) {
		memcpy(buffer+i, &i, 1);
	}

	for (int i = 0; i < nFiles; i++) {
		if (fds[i] < 0) {
			continue;
		}
		if ((err = tfs_writeFile(fds[i], buffer, nBytes)) < 0) {
			printf("Error writing %d bytes to file%d (%d)\n", nBytes, i, err);
		}
	}
	free(buffer);
	return 0;
}

int testOpenFiles(void) {
	if (fds == NULL) {
		fds = calloc(nFiles, sizeof(fileDescriptor));
	}
	int retVal;
	char name[9] = {0};
	char name2[9] = {0};
	for (int i = 0; i < nFiles; i++) {
		sprintf(name, "file%d", i);
		memcpy(name2, name, 9);
		if ((retVal = tfs_openFile(name)) < 0) {
			printf("Error opening %s (%d)\n", name2, retVal);
		} else {
			printf("%s opened\n", name2);
		}
		fds[i] = retVal;
	}
	return nFiles;
}

int testMakeReadOnly(void) {
	int retVal;
	char name[9] = {0};
	for (int i = 0; i < nFiles; i++) {
		sprintf(name, "file%d", i);
		if ((retVal = tfs_makeRO(name)) < 0) {
			printf("Error making %s read-only (%d)\n", name, retVal);
		}
	}
	return 0;
}

int testReadOnly(void) {
	printf("\n===== Read-Only =====\n");
	printf("%d files from the first run should be read-only (0 if already run again)\n", nFiles);
	int err, ret = 0;;
	char buffer[] = "This file is read-only.";
	for (int i = 0; i < nFiles; i++) {
		if (fds[i] < 0) {
			continue;
		}
		err = tfs_writeFile(fds[i], buffer, sizeof(buffer));
		if (err == ERR_ACCESS) {
			printf("file%d is read-only\n", i);
		} else if (err < 0) {
			printf("Unexpected error (%d)\n", err);
		} else {
			ret = 1;
		}
	}
	return ret;
}

int testMakeReadWrite(void) {
	int retVal;
	char name[9] = {0};
	for (int i = 0; i < nFiles; i++) {
		sprintf(name, "file%d", i);
		if ((retVal = tfs_makeRW(name)) < 0) {
			printf("Error making %s read/write (%d)\n", name, retVal);
		}
	}
	return 0;
}

int testReadWrite(void) {
	printf("\n===== Read/Write =====\n");
	printf("%d files from the last run should be read/write\n", nFiles);
	int err, ret = 0;;
	char buffer[] = "This file was written to.";
	for (int i = 0; i < nFiles; i++) {
		if (fds[i] < 0) {
			continue;
		}
		err = tfs_writeFile(fds[i], buffer, sizeof(buffer));
		if (err == ERR_ACCESS) {
			ret = 1;
		} else if (err < 0) {
			printf("Unexpected error (%d)\n", err);
		} else {
			printf("file%d is read/write\n", i);
		}
	}
	return ret;
}

int testRemoveDir(void) {
	printf("\n===== Remove Directory =====\n");
	int err = tfs_removeDir("/foo");
	if (err == ERR_NOTEMPTY) {
		printf("/foo is not empty. Deleting contents.\n");
	} else if (err < 0) {
		printf("Error removing /foo (%d)\n", err);
	}
	fileDescriptor fd;
	char foobar[] = "/foo/bar/fizzbuzz";
	if ((fd = tfs_openFile(foobar)) < 0) {
		printf("Error opening /foo/bar/foobar (%d)\n", fd);
	} else {
		if ((err = tfs_deleteFile(fd)) < 0) {
			printf("Error deleting /foo/bar/foobar (%d)\n", err);
		}
	}
	char baz[] = "/foo/baz";
	if ((fd = tfs_openFile(baz)) < 0) {
		printf("Error opening /foo/baz (%d)\n", fd);
	} else {
		if ((err = tfs_deleteFile(fd)) < 0) {
			printf("Error deleting /foo/baz (%d)\n", err);
		}
	}
	char bar[] = "/foo/bar";
	if ((err = tfs_removeDir(bar)) < 0) {
		printf("Error removing /foo/bar (%d)\n", err);
	}
	if ((err = tfs_removeDir("/foo")) < 0) {
		printf("Error removing /foo (%d)\n", err);
	}
	return 0;
}

int testRename(void) {
	printf("\n===== Rename =====\n");
	char foobar[] = "/foo/bar/foobar";
	int fd, err;
	if ((fd = tfs_openFile(foobar)) < 0) {
		printf("Error opening /foo/bar/foobar (%d)\n", fd);
	}
	if ((err = tfs_rename(fd, "fizzbuzz")) < 0) {
		printf("Error renaming /foo/bar/foobar (%d)\n", err);
	} else {
		printf("/foo/bar/foobar renamed to fizzbuzz\n");
	}
	if ((err = tfs_closeFile(fd)) < 0) {
		printf("Error closing /foo/bar/fizzbuzz (%d)\n", err);
	}
	return 0;
}

int testRemoveAll(void) {
	printf("\n===== Remove All =====\n");
	printf("Removing all files and directories under root\n");
	int err = tfs_removeAll("/");
	if (err < 0) {
		printf("Error removing all under / (%d)\n", err);
	}
	printf("Success!\n");
	return 0;
}

int main(int argc, char* argv[]) {
	char* diskName = DEFAULT_DISK_NAME;
	int diskSize = DEFAULT_DISK_SIZE;
	if (argc > 1) {
		diskName = argv[1];
	}
	if (argc > 2) {
		diskSize = atoi(argv[2]);
	}

	if (testMount(diskName, diskSize) < 0) {
		return -1;
	}

	int err, firstRun = testFirstRun();
	int doDelete = 0;
	if (firstRun < 0) {
		if (fds) free(fds);
		return -1;
	} else if (firstRun == 1) {
		testCreateFiles();
		if ((err = tfs_writeFile(demoFD, (char*) &nFiles, 1)) < 0) {
			printf("Error writing to demo (%d)\n", err);
		}
		testCreateDirs();
		testCreatePaths();
		testWriteFiles();
	} else {
		testOpenFiles();
		if (testReadOnly() != 0) {
			testReadWrite();
			testRemoveDir();
			doDelete = 1;
		} else {
			testRename();
		}
	}

	if ((err = tfs_closeFile(demoFD)) < 0) {
		printf("Error closing demo (%d)\n", err);
	}

	for (int i = 0; i < nFiles; i++) {
		if ((err = tfs_closeFile(fds[i])) < 0) {
			printf("Error closing fd %d (%d)\n", fds[i], err);
		}
	}

	if (doDelete) {
		testRemoveAll();
	} else if (firstRun) {
		testMakeReadOnly();
	} else {
		testMakeReadWrite();
	}
	free(fds);

	printf("\n===== Print Tree =====\n\n");

	if ((err = tfs_readdir()) < 0) {
		printf("Error printing tree (%d)\n", err);
	}

	if ((err = tfs_unmount()) < 0) {
		printf("Error unmounting '%s' (%d)\n", diskName, err);
	}
}
