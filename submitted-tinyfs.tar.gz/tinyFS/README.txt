Pixie Macke - Project 4: TinyFS

# libDisk
The implementation of libDisk is primarily a 
wrapper around io system calls. All 
errors returned by libDisk, except for argument 
validation, are directly translated from the 
value of errno set by a system call. For 
example, if errno is set to EROFS, the return 
value will be ERR_RDONLYFS.

### int openDisk(char* filename, int nBytes)
This function makes use of the open() and 
ftruncate() system calls. When nBytes is 0, the 
disk is opened by calling open(filename, 
O_RDWR). When nBytes > 0, the disk is opened by 
calling open(filename, O_RDWR | O_CREAT) and 
space is allocated by calling ftruncate(fd, n) 
where n is the nearest multiple of 
BLOCKSIZE to nBytes, rounded down. On success, 
the return value is the file descriptor returned 
by open(). This simplifies the library by 
letting the OS handle the open disk numbers. On 
error, the return value is the translated errno 
(see above) or ERR_INVALID if nBytes < 
BLOCKSIZE.

### int closeDisk(int disk)
This function is just a simple wrapper around 
the close() system call which translates errno, 
if set, to a TinyFS error (see above).

### int readBlock(int disk, int bNum, void* block)
### int writeBlock(int disk, int bNum, void* block)
These two functions are very similar, they wrap 
the pread() and pwrite() system calls 
respectively. The physical address of the block 
on the disk is calculated by multiplying bNum by 
BLOCKSIZE. The address is checked to make sure 
it is within the disk bounds. This is done by 
calling the lseek() system call to seek to the 
end of the disk/file, which returns the size 
disk. If the address + BLOCKSIZE > the disk 
size, the block is not within the disk. Then 
pread() and pwrite() are called to read or 
write, respectively, BLOCKSIZE bytes to/from the 
calculated physical address. Using pread() and 
pwrite() instead of read() and write() allow for 
reading from the disk at any offset, so the 
current position of the disk doesn't need to be 
tracked. On success, the return value is 0. On 
error, the return value is the translated errno 
(see above) or ERR_INVALID if the block is not 
within the bounds of the disk.


# libTinyFS
This implementation has two main typedefs, Block 
and File, in addition to the required 
fileDescriptor, though these two structs aren't 
exposed to the user. Block is a struct used for 
holding block data in memory. It contains the 
block number, a buffer of BLOCKSIZE bytes, and a 
modified flag for determining if the block needs 
to be written back to the disk. File is a struct 
used for keeping track of the state of open 
files. It contains the file's inode's block 
number, as well as its parent directory's inode 
block number, an 8 byte buffer for the 
filename, the file size, flags, the current 
pointer, as well as a Block used for buffering. 
A global Block is used for keeping the 
superblock in memory, and a global File is used 
for keeping the root directory memory. A global 
slice of File structs is used for the open file 
table (see below). Additionally, two 
globals, nextFD and nextBlock, are for 
quick access to a free file descriptor or 
block after one has been closed or freed. They 
are set once a file descriptor or block has been 
freed. After the file descriptor from nextFD is 
used, the next free file descriptor is found by 
iterating through the open file table for any 
Files that have been freed by setting their 
inode block number to 0. If there are none, a 
new File is appended and the file descriptor is 
the last index of the open file table. After the 
block number from nextBlock is used, the 
next free block is found by determining the 
first set bit in the superblock's bitmap. 
This is done with the __builtin_ctz() function 
of gcc to perform a "count trailing zeros" 
operation, on the first non-zero word of the 
bitmap. Blocks are addressed using a single 
byte, which limits the maximum disksize for this 
filesystem to 256 blocks, or 65,536 bytes. Any 
errors returned internally by libDisk are 
immediately returned to the user. The additional 
features implemented were hierarchical 
directories, as well as directory listing and 
file renaming, and read-only and writeByte 
support.

## File Table
The open file table is stored as a slice of 
File structs. A slice is a data type, based on 
the definition in Golang (Go), which I have 
written and used in previous projects. It is a 
dynamic array structured as a "fat pointer," 
which is a struct containing a pointer to a 
malloced array, the length, or number of items 
in the array, and the capacity, or maximum 
number of items space is allocated for. This 
implementation of a slice also stores the size 
of an element, since the array is stored as a 
void pointer. A slice can be appended to one 
element at a time, which is potentially done 
when a file is opened. If there is capacity 
beyond the length of the slice, the element is 
simply copied into the next spot. Otherwise, if 
the slice is full (length equals capacity), the 
slice is realloced with a larger capacity, x2 if 
length is < 1024, else x1.25. This allows for a 
dynamic size while reducing the number of 
necessary allocations. The specific growth rate 
was taken from the implementation in Go. A slice 
can also be resized to a smaller length, which 
is done when the file at the end of the file 
table is closed. It simply decrements the 
slice's length by one, and if the new length is 
less than half of the capacity, the memory past 
the new length is freed and the capacity is set 
as the new length. This prevents needing to 
allocate a new File struct every time a file is 
opened while still freeing memory that is no 
longer in use.

## Superblock
The superblock is stored in block 0 on the disk. 
It contains the block number for the inode of 
the root directory, which is fixed at block 1, 
in byte 3. The rest of the 
bytes are used to store a bitmap of free blocks 
on the disk, offset by 2 to maximize the bits 
for blocks available after the superblock and 
root inode. The bitset is stored as a set of 
big-endian unsigned 32-bit integer words, 
prefixed by the length in bits. Big-endianness 
was specifically chosen so that bit 0 of byte 0 
is bit 0 of the bitmap. This allows for setting 
and clearing bits by byte instead of by word.

## File Storage
Files are stored on disk as a linked list of 
blocks. The first block of a file is always an 
inode block. It stores metadata about the file, 
8 bytes for the filename, 1 byte for the inode 
block number of the file's parent directory, 4 
bytes for the file size, and 1 byye for flags. 
Given the limited size of the filesystem, the 
remaining bytes of the inode block are used to 
store the beginning of the file data, similar 
to ext4's inline data feature. This allows for 
small files to be stored within only one block. 
Extent blocks are simply the 4 byte block header 
and the rest of the bytes are for file data. 
Each file block contains a pointer to the next 
block of the file. If a block is the final block 
of a file, its pointer is 0. This was chosen 
because block 0 is the superblock, so will never 
be a part of a file's data.

## Directory Storage
Directories are stored exactly the same as files 
with a few differences. The data of a directory 
is a set of 9-byte entries, mapping filenames to 
block numbers. The first 8 bytes of an entry 
stores the filename and the last byte is the 
block number of the inode for the file with that 
filename. Entries are stored consecutively 
within a block, except for the trailing bytes at 
the end of each block, which are kept blank to 
avoid splitting entries across blocks. The 
directory's size is stored as the total number 
of bytes allocated for its blocks, not for the 
amount of entries. This was chosen to reduce the 
number of times the inode needs to be updated. 
The final change between a directory and a 
normal file is that a flag is set in to indicate 
that it is a directory.

## File Names
File and directory names must alphanumeric and 
between 1 and 8 bytes, inclusive. Otherwise an 
error is returned. Absolute path parsing 
operates similarly to Unix. A leading "/" is 
optional, consecutive "/"s are treated as one, 
and a path ending with a "/" is treated as a 
directory. Where this implementation differs is 
that paths always start at the root directory, 
regardless of whether a leading "/" is included.

### int tfs_mkfs(char* filename, int nBytes)
This function creates a disk using openDisk() 
and then initializes each block using 
writeBlock(). The superblock is written to block 
0, the root inode is written to block 1, and the 
remaining blocks in the disk are all initialized 
as free blocks. After the blocls are 
initialized, the newly-created disk is closed 
using closeDisk(). Since two blocks are required 
to initialize the filesystem, for the superblock 
and root inode, and at least one block is 
required for the filesystem to usably store a 
file, the disk must be at least 3 blocks large. 
Given blocks are addressed using one byte, the 
disk is limited to a maximum size of 256 blocks. 
tfs_mkfs() does not check if the disk already 
exists, and so will overwrite any existing file 
at filename. On success, the return value is 0. 
On error, the return value is one of: the error 
returned by libDisk, ERR_INVALID if nBytes is 
too small, or ERR_NOSPACE if nBytes is too 
large.

### int tfs_mount(char* diskname)
This function mounts a mounts a filesystem at 
diskname that has previously been created with 
tfs_mkfs(). Only one filesystem may be mounted 
at a time, so attempting to mount multiple will 
return an error. The disk must exist and contain 
a valid filesystem. This is verified by reading 
each block on the disk using readBlock() and 
checking the block headers. Byte 0 must 
be a valid block type, byte 1 must be 0x44, the 
magic number, and byte 3 must be 0, otherwise 
an error is returned. After verifying it is a 
valid filesystem, the open file table is 
initialized with a default capacity of 8. This 
was an arbitrary starting size, but was kept 
small to avoid overallocation. On success, the 
return value is 0. On error, the return value is 
the error returned by libDisk, ERR_NOTBLOCK if 
the file at diskname is not a valid TinyFS 
filesystem, or ERR_BUSY if another disk is 
already mounted.

### int tfs_unmount()
This function unmounts a filesystem previously 
mounted with tfs_mount(). This will reset the 
state of the filesystem, free the open file 
table, writes the superblock to disk using 
writeBlock(), and closes the disk using 
closeDisk(). On success, the return value is 0. 
On error, the return value is the error returned 
by libDisk or ERR_NODEVICE if no filesystem is 
mounted.

### fileDescriptor tfs_openFile(char* name)
This function opens, and creates if it doesn't 
exist, a file at name. This must be an absolute 
path to a file in an existing directory. The 
value pointed to by name will be modified. This 
function first traverses the path, from the root 
directory to the parent directory of the desired 
file. If any directories along the path don't 
exist, an error is returned. Directories may be 
opened as files, but any attempts to read or 
write to them will return an error. This is 
primarily to allow renaming of directories. If 
the file doesn't exist, an inode is allocated 
and initialized as an empty file with read/write 
permissions, and the first free entry in the 
file's directory is set to the file, with its 
address the inode of the file. If the directory 
is full, a new block is allocated and added to 
the end of the directory. After the inode has 
been read or created, the file metadata is put 
into the first free File in the open file table, 
or appended if the table is full. Upon opening, 
the file's pointer is set to 0. On success, the 
return value is the file descriptor, which is 
the index of the File in the open file table. On 
error, the return value is one of: the error 
returned by libDisk, ERR_INVALID if any name in 
the path is not alphanumeric or name is empty, 
ERR_NAMETOOLONG if any name in the path is 
longer than 8 characters, ERR_ISDIR if the file 
at name is a directory, ERR_NOSPACE if there are 
not enough free blocks on the disk to create a 
new file, or ERR_IO if the block that should 
contain the file's inode is not an inode block.

### int tfs_closeFile(fileDescriptor fd)
This function closes the file currently open at 
index fd of the open file table. The contents of 
the file's buffer is written to disk, the buffer 
is cleared to avoid having potentially personal 
information kept in memory, the File struct's 
state is reset, and any free Files at the end of 
the open file table are dropped, though they 
may still exist in memory (see above). On 
success, the return value is 0. On error, the 
return value is the error returned by libDisk, 
or ERR_BADF if the file of the provided file 
descriptor isn't currently open.

### int tfs_writeFile(fileDescriptor fd, char* buffer, int size)
This function writes size bytes from buffer to 
the file for the provided file descriptor, 
starting at the front of the file. The file must 
be open and have write permissions. If size is 
larger than the current size of the file, new 
blocks are allocated one at a time until the 
entire file has been written. If size is smaller 
than the current size of the file, any remaining 
blocks that were previously allocated are freed 
for use elsewhere. On success, the return value 
is 0. On error, the return value is one of: the 
error returned by libDisk, ERR_BADF if the file 
isn't currently open, ERR_ACCESS if the file 
doesn't have write permissions, ERR_ISDIR if the 
file is a directory, ERR_NOSPACE if there aren't 
enough free blocks to write the entirety of 
buffer, or ERR_IO if some unexpected error 
occurs resulting in the entirety of buffer to 
not be written (this should never happen but is 
included for safety).

### int tfs_deleteFile(fileDescriptor fd)
This function deletes the file for the provided  
file descriptor, starting at the front of the 
file. The file must be open and have write 
permissions. First, all of the blocks belonging 
to the file are freed. The entry for the file is 
found in it's parent directory and is cleared. 
If the directory entry was in the last block of 
the directory amd was the only entry set in that 
block, the block is freed, and the directory is 
shortened. After all the blocks have been freed 
and entry dropped, the superblock is updated 
and the file is closed, releasing the open file 
table entry. On success, the return value is 0. 
On error, the return value is one of: the 
error returned by libDisk, ERR_BADF if the file 
isn't currently open, ERR_ACCESS if the file 
doesn't have write permissions, ERR_ISDIR if the 
file is a directory.

### int tfs_readByte(fileDescriptor fd, char* buffer)
This function reads one byte from the file for 
the provided file descriptor, at the file's 
current pointer position. The file must be 
open. If there are no more bytes to read, 
ERR_EOF is returned. This isn't neccessarily an 
actual error, just a way to signal end of file. 
If the pointer is at the first byte of the file 
or last byte of a block, then inode or next 
block, respectively, of the file, if there is 
one, is read from disk. Finally, the file's 
pointer is incremented by one. On success, the 
return value is 0. On error, the return value is 
one of: the error returned by libDisk, ERR_BADF 
if the file isn't currently open, ERR_ISDIR if 
the file is a directory, or ERR_EOF if the 
file's pointer is at or past the file's size 
(again, this isn't really an error, but an eof 
signal).

### int tfs_seek(fileDescriptor fd, int offset)
This function sets the pointer of the file for 
the provided file descriptor to the given offset 
from the start of the file. The file must be 
open. If the new pointer is in a different block 
than the current pointer, the file is read from 
disk until the desired block is in the file's 
buffer. Like the lseek() system call, the 
pointer can be set past the end of the file. If 
so, any future calls to tfs_readByte() will 
return ERR_EOF until the next write, and the 
next call to tfs_writeByte() will fill the gap 
with 0s. On success, the return value is 0. On 
error, the return value is one of: the error 
returned by libDisk, ERR_BADF if the file isn't 
currently open, ERR_ISDIR if the file is a 
directory, or ERR_INVALID if offset is negative.

## Read-only and writeByte Support

### int tfs_makeRO(char* name)
### int tfs_makeRW(char* name)
These two functions are very similar. They make 
a file read-only or read/write, respectively. 
The file must not be open. The provided name 
must be an absolute path to a file in an 
existing directory. The value pointed to by 
name will be modified. This function first 
traverses the path, from the root directory to 
the parent directory of the desired file. If any 
directories along the path don't exist, an error 
is returned. Then the file's directory entry os 
found in its parent directory. If an entry 
doesn't exist, an error is returned. The file's 
inode block is read from disk, the write 
permissions bit of the flags byte is cleared or 
set, respectively, and the block is written back 
to disk.

### int tfs_writeByte(fileDescriptor fd, unsigned int data)
This function operates similar to 
tfs_readByte(), but writes a byte to the file's 
pointer instead of reading from it. If the 
pointer is past the size of the file, as can 
be done with tfs_seek(), the gap from size to 
pointer is filled with 0s before writing the 
provided byte. If the pointer is at the first 
byte of the file or last byte of a block, then 
inode or next block, respectively, of the file, 
if there is one, is read from disk. The block 
the byte was written to will not be written to 
disk until a new block needs to be read, thanks 
to the modified flag in the Block struct. 
Finally, the file's pointer is incremented by 
one. On success, the return value is 0. On 
error, the return value is one of: the error 
returned by libDisk, ERR_BADF if the file isn't 
currently open, ERR_ACCESS if the file doesn't 
have write permission, ERR_ISDIR if the file is 
a directory, ERR_NOSPACE if there aren't enough 
free blocks to write the entirety of buffer, or 
ERR_FAULT if a block points to 0 before the end 
of the file.

## Hierarchical Directories

### int tfs_createDir(char* dirName)
This function creates a directory at dirName. 
This must be an absolute path to a file in an 
existing directory. The value pointed to by 
dirName will be modified. This function 
replicates the functionality of the `-p` option 
for the `mkdir` command, creating any missing 
directories along the path, and succeeding if 
the directory already exists. Directory inodes 
are created the exact same as new files, with 
the addition of setting the isDir flag of the 
flags byte, and the directory isn't assigned a 
file descriptor or added to the open file table. 
On success, the return value is 0. On error, the 
return value is one of: the error returned by 
libDisk, ERR_INVALID if any name in the path is 
not alphanumeric or name is empty, 
ERR_NAMETOOLONG if any name in the path is 
longer than 8 characters, ERR_ISDIR if the file 
at name is a directory, ERR_NOTDIR if any of the 
names along the path exist but aren't 
directories, ERR_NOSPACE if there are not enough 
free blocks on the disk to create a new 
directory, or ERR_IO if the block that should 
contain the directory's inode is not an inode 
block.

### int tfs_removeDir(char* dirName)
This function deletes an empty directory at 
dirName. This must be an absolute path to a file 
in an existing directory. The value pointed 
to by dirName will be modified. The directory 
must not be open. To ensure the directory is 
empty, every directory entry is checked to make 
sure it's not pointing to a file. After checking 
that the directory is empty, it is deleted like 
any other file. On success, the return value is 
0. On error the return value is one of: the 
error returned by libDisk, ERR_INVALID if any 
name in the path is not alphanumeric or name is 
empty, ERR_NAMETOOLONG if any name in the path 
is longer than 8 characters, ERR_BUSY if the 
directory is currently open, ERR_ACCESS if the 
file doesn't have write permissions, ERR_NOENTRY 
if any directories along the path don't exist, 
ERR_NOTDIR if the file at dirName is not a 
directory, or ERR_NOTEMPTY if the directory 
isn't empty.

### int tfs_removeAll(char* dirName)
This function deletes an existing directory, and 
all of its contents, at dirName. This must be an 
absolute path to a file in an existing 
directory. The value pointed to by dirName 
will be modified. The directory must not be 
open. The files and directories pointed to by 
each entry of the directory is recursively 
deleted, deleting each directory after their 
contents. After deleting all of the contents of 
the directory at dirName, the directory file 
itself is deleted like any other file, unless 
dirName is the special "/" token, in which case 
all of the contents are deleted, but the root 
directory file is kept. On success, the return 
value is 0. On error the return value is one of: 
the error returned by libDisk, ERR_INVALID if 
any name in the path is not alphanumeric or 
dirName is empty, ERR_NAMETOOLONG if any name in 
the path is longer than 8 characters, ERR_BUSY 
if the directory or any of its contents are 
currently open, ERR_NOENTRY if any directories 
along the path don't exist, or ERR_NOTDIR if the 
file at dirName is not a directory.

## Directory Listing and File Renaming

### int tfs_rename(fileDescriptor fd, char* newName)
This function renames the file for the provided 
file descriptor to newName. The file must be 
open and have write permissions. the new name 
must be alphanumeric and between 1 and 8 bytes 
long, inclusive. The file's inode os read from 
disk, the filename is updated, and it is written 
back to disk. The inode of the file's parent 
directory is read from disk, and the file's 
directory entry is found. The filename in the 
entry is updated and the block containing it is 
written back to disk. Finally, the new name is 
copied into the File struct. Only renaming 
within a file's parent directory is supported. 
However, directories themselves may be renamed. 
This means newName should not be a path, just 
the file's name. Attempting to use an absolute 
path to rename a file will return an error. On 
success, the return value is 0. On error, the 
return value is one of: the error returned by 
libDisk, ERR_BADF if the file isn't currently 
open, or ERR_INVALID if newName is not 
alphanumeric or is an absolute path.

### int tfs_readdir()
This function prints all of the directories and 
files in the filesystem to stdout. The output 
format is a tree, with each level indented by an 
additional 4 characters, similar to the output 
of the `tree` command. This function starts by 
seeking the root directory to the start of the 
file. Each directory entry is recursively 
traversed using a depth first search, and each 
directory and file name is printed along the 
way, with directory names having a "/" appended 
to the end. On success, the return value is 0. 
On error, the return value is the error returned 
by libDisk.

# Demo Program
The demo program takes two optional arguments, a 
disk name and a disk size. If either isn't 
provided, the defaults defined in tinyFS.h are 
used. The program has 3 different stages, for 
each time you run it. The first run makes the 
filesystem, creates files and directories, 
writes to files, and makes files read-only. The 
second run opens existing files, tests that 
files are read-only, makes those files 
read/write, and renames a file. The third run 
opens existing files, tests that they are now 
read/write, ensures a non-empty directory can't 
be deleted, deletes specific files, removes 
empty directories, and finally removes all 
remaining files and directories under the root 
directory. After each run, the directory tree is 
printed to stdout.

## Read-only and writeByte Support
Read-only support is tested in the demo program 
by making files read-only in the first run with 
the testMakeReadOnly() function. In the second 
run, the testReadOnly() function makes sure 
they're read-only by attempting to write to them 
and expecting an error, and makes them 
read/write with the testMakeReadWrite() 
function. In the third run, they are tested to 
make sure they've been made read/wrote by 
attempting to write to them with the 
testReadWrite() function.

The functionality of writeByte() is tested in 
the testFirstRun() function, which writes a 
single byte to the file 'demo'.

## Hierarchical Directories
The creation of directories is tested in the 
first run. Directories are created in the root 
directory with testCreateDirs(), as well as 
with absolute paths multiple directories deep 
with testCreatePaths().

Remove empty directories is tested in 
testRemoveDirs(), which first attempts to remove 
a non-empty directory before deleting each file 
under it, and removing the directory now that it 
is empty. Recursively removing a directory is 
tested in testRemoveAll() where 
tfs_removeAll() is called with the special "/" 
token.

The directories used for this testing are /foo 
and /foo/bar. The function testRemoveDir() 
removes /foo.

## Directory Listing and File Renaming
Directory listing is done at the end of each 
run. In the third run, after testRemoveAll() is 
run, the directory listing should be just an 
empty root directory.

File renaming is tested in the second run with 
testRename(), which renames the file 
/foo/bar/foobar to /foo/bar/fizzbuzz. The 
renaming is then verified in the third run, when 
/foo/bar/fizzbuzz is deleted in testRemoveDir().

## Errors
If an error occurs, an error message is printed, 
along with the error number in parantheses, to 
stdout.

# Additional Notes
tinyFS_errno.h is included in tinyFS.h, so only 
tinyFS.h needs to be included in a user 
application.

I have created a macro called dbg(), which is 
blank normally, but an alias for fprintf(stderr, 
...) when DEBUG_FLAG is defined. This can be 
done with `make debug` which just adds 
-DDEBUG_FLAG to gcc. When compiled normally with 
`make`, the only print statements will be from 
the demo.

I've also added tinyFSDisk to `make clean` so 
the default disk gets deleted.

The slice data structure used for the open file 
table is defined in slice.h and slice.c, and the 
bitmap used for free blocks is defined in 
bitset.h and bitset.c.

The names passed to libTinyFS functions cannot 
be literals and must be modifiable. Passing a 
string literal, for example to tfs_openFile(), 
will result in a SEGFAULT.
