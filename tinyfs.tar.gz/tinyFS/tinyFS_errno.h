#ifndef TINYFS_ERRNO_H
#define TINYFS_ERRNO_H

/* End of file */
#define ERR_EOF -1
/* Permission denied */
#define ERR_ACCESS -2
/* Resource temporarily unavailable */
#define ERR_AGAIN -3
/* Bad file descriptor */
#define ERR_BADF -4
/* Device or resource busy */
#define ERR_BUSY -5
/* Disk quota exceeded */
#define ERR_DQUOTA -6
/* Bad address */
#define ERR_FAULT -7
/* Interrupted by a signal handler */
#define ERR_INTERRUPT -8
/* Invalid argument */
#define ERR_INVALID -9
/* Input/output error */
#define ERR_IO -10
/* Is a directory */
#define ERR_ISDIR -11
/* Too many levels of symbolic links */
#define ERR_LOOP -12
/* Too many open files */
#define ERR_MFILES -13
/* Filename too long */
#define ERR_NAMETOOLONG -14
/* No such device */
#define ERR_NODEVICE -15
/* No such file or directory */
#define ERR_NOENTRY -16
/* Not enough space/cannot allocate memory */
#define ERR_NOMEMORY -17
/* No space lefto on disk */
#define ERR_NOSPACE -18
/* Block device required */
#define ERR_NOTBLOCK -19
/* Not a directory */
#define ERR_NOTDIR -20
/* Directory not empty */
#define ERR_NOTEMPTY -21
/* Value too large to be stored in datatype */
#define ERR_OVERFLOW -22
/* Operation not permitted */
#define ERR_PERMIT -23
/* Read-only filesystem */
#define ERR_RDONLYFS -24
/* Invalid seek */
#define ERR_SEEKPIPE -25
/* Text file busy */
#define ERR_TXTBUSY -26
/* Unknown error */
#define ERR_UNKNOWN -128

#define IS_TFS_ERROR(err) ((err) < 0 && (err) >= ERR_TXTBUSY)

// TINYFS_ERRNO_H
#endif
