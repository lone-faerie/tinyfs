#include <stdlib.h>
#include <string.h>

#include "slice.h"

slice_t slice_new(int capacity, int size) {
	slice_t s;
	s.ptr = malloc(capacity * size);
	s.len = 0;
	s.cap = capacity;
	s.size = size;
	return s;
}

slice_t slice_copy(slice_t s) {
	slice_t new_s = slice_new(s.cap, s.size);
	memcpy(new_s.ptr, s.ptr, s.len*s.size);
	new_s.len = s.len;
	return new_s;
}

void slice_free(slice_t s) {
	free(s.ptr);
}

slice_t slice_append(slice_t s, void* value) {
	if (s.cap == 0) {
		s = slice_new(8, s.size);
	} else if (s.len >= s.cap) {
		s.cap += (s.cap > 1024) ? s.cap / 4 : s.cap;
		s.ptr = realloc(s.ptr, s.cap * s.size);
	}
	memcpy(s.ptr + (s.len++ * s.size), value, s.size);
	return s;
}

slice_t slice_grow(slice_t s, int n) {
	if (s.cap == 0) {
		s = slice_new(8, s.size);
	}
	while (n > s.cap - s.len) {
		s.cap += (s.cap > 1024) ? s.cap / 4 : s.cap;
		s.ptr = realloc(s.ptr, s.cap * s.size);
	}
	memset(s.ptr+(s.len * s.size), 0, n * s.size);
	s.len += n;
	return s;
}

slice_t slice_trim(slice_t s, int (*canDrop)(void*)) {
	int newLen = s.len;
	for (int i = s.len-1; i >= 0; i--) {
		if (!canDrop(s.ptr+(i * s.size))) {
			break;
		}
		--newLen;
	}
	if (newLen < s.cap/2) {
		s.ptr = realloc(s.ptr, newLen*s.size);
		s.cap = newLen;
	}
	s.len = newLen;
	return s;
}
